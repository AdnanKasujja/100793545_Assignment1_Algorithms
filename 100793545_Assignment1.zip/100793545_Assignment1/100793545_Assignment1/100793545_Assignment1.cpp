// 100793545_Assignment1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<fstream>
using namespace std;

//A class for the item
class Item //I will use this class to demonstrate inserting new products into a dynamic array
{
public:
    int ID;
    string Name;
    double Price;
    string Category;
};

class Items2 //I will use this second class to demonstrate searching, sorting and updating, in a static array
{
public:
    int ID;
    string Name;
    double Price;
    string Category;

    Items2(int id, string name, double price, string category)
    {
        ID = id;
        Name = name;
        Price = price;
        Category = category;
    }
};

//Function to print the catalogue entries in a sort of table format
void printCatalogue(Item * items, int sizeOfCatalogue)
{
    for (int i = 0; i < sizeOfCatalogue; i++)
    {
        cout << "Item Listing # " << i + 1 << "\t";

        cout << items[i].ID << "\t";

        cout << items[i].Name << "\t";

        cout << items[i].Price << "\t";

        cout << items[i].Category << endl;
    }
}

int main()
{
    //******************************Beginning of demonstration for insertion and updating******************************************

    int sizeOfCatalogue; // I want to let the user be able to determine the size of the array
    cout << "Please enter the number of items you wish to register for the catalogue: ";
    cin >> sizeOfCatalogue;

    Item* items = new Item[sizeOfCatalogue]; //Array of Catalogue Items
    
    for (int i = 0; i < sizeOfCatalogue; i++)
    {
        cout << "Item Listing # " << i + 1<< endl;

        Item a;
        //Allowing the user to input information about the item in the catalogue
        cout << "ID: ";
        cin >> a.ID;
        cout << "Name: ";
        cin >> a.Name;
        cout << "Price: ";
        cin >> a.Price;
        cout << "Category: ";
        cin >> a.Category;

        items[i] = a;
    }

    char userChoice; //If the user wants/needs to increase the size of the catalogue/add more items
    cout << "Would you like to add more items to the catalogue?";
    cin >> userChoice;

    if (userChoice == 'N' || userChoice == 'n')
    {
        printCatalogue(items, sizeOfCatalogue);
        delete[]items;
        return 0;
    }

    int newCatalogueSize;
    cout << "Please enter the new size of the catalogue: ";
    cin >> newCatalogueSize; //Assuming that the user inputs a valid number lol

    Item* newItems = new Item[newCatalogueSize]; //Allocating the new array
    for (int i = 0; i < sizeOfCatalogue; i++)
    {
        newItems[i] = items[i]; // copying elements from the old array into the new array
    }

    delete[] items; //deleting the previous array
    items = newItems; //Pointing to the new address

    for (int i = sizeOfCatalogue; i < newCatalogueSize; i++)
    {
        cout << "Item Listing # " << i + 1 << endl;

        Item a;
        //Allowing the user to input information for the new array
        cout << "ID: ";
        cin >> a.ID;
        cout << "Name: ";
        cin >> a.Name;
        cout << "Price: ";
        cin >> a.Price;
        cout << "Category: ";
        cin >> a.Category;

        items[i] = a;
    }
    printCatalogue(items, newCatalogueSize);

    delete[] items;
    
    //********************************End of demonstration for insertion and updating******************************************



    //********************************Beginning of demonstartion for sorting and searching************************
    /*
    Items2 items[50] =
    {
        {57353, "Camera SBBHC", 546.88, "Electronics"},
        {40374, "Smartphone ILGCU", 947.54, "Electronics"},
        {34863, "Biography XPESK", 287.31, "Books"},
        {18086, "Shirt ZQLTI", 439.07, "Clothing"},
        {16041, "Jacket OTBKQ", 986.73, "Clothing"},
        {43566, "Mystery COKPK", 836.57, "Books"},
        {69260, "Toaster FODKJ", 867.6, "Home & Kitchen"},
        {30895, "Knife Set KGFUF", 385.77, "Home & Kitchen"},
        {19897, "Blender DPKLR", 488.62, "Home & Kitchen"},
        {87296, "Skirt IRTZX", 261.08, "Clothing"},
        {68215, "Laptop QLBQC", 404.21, "Electronics"},
        {68097, "Camera SGSRZ", 36.39, "Electronics"},
        {26556, "Novel METLI", 376.45, "Books"},
        {30483, "Knife Set WRSZZ", 55.97, "Home& Kitchen"},
        {62422, "Camera VFQWS", 382.69, "Electronics"},
        {22806, "Smartwatch VVFNT", 203.55, "Electronics"},
        {24976, "Pants YZMAK", 449.56, "Clothing"},
        {30631, "Headphones JFGYQ", 115.08, "Electronics"},
        {27939, "Textbook TWQKZ", 108.5, "Books"},
        {41355, "Headphones JOUXM", 211.57, "Electronics"},
        {94162, "Laptop WRJOZ", 956.53, "Electronics"},
        {28710, "Dress FRSMO", 879.09, "Clothing"},
        {90291, "Pants TIPUD", 853.38, "Clothing"},
        {20368, "Shirt FQFPK", 83.19, "Clothing"},
        {68960, "Blender OMDPS", 720.06, "Home& Kitchen"},
        {40852, "Novel IRROY", 603.68, "Books"},
        {97895, "Blender KSJHL", 123.25, "Home& Kitchen"},
        {96314, "Cutting Board LUICX", 628.29, "Home& Kitchen"},
        {85719, "Laptop GZORF", 641.33, "Electronics"},
        {98625, "Mystery BOPTP", 160.68, "Books"},
        {66208, "Blender GCZSK", 161.83, "Home& Kitchen"},
        {86128, "Biography ASTVE", 90.44, "Books"},
        {10889, "Shirt DNRZU", 316.48, "Clothing"},
        {82777, "Shirt OZWXU", 790.46, "Clothing"},
        {43451, "Mixer CKVJQ", 379.5, "Home& Kitchen"},
        {12848, "Toaster VZXUE", 867.97, "Home& Kitchen"},
        {17646, "Biography BPWXR", 424.83, "Books"},
        {85197, "Cutting Board IJVPP", 986.89, "Home& Kitchen"},
        {13471, "Knife Set TPCMO", 831.9, "Home& Kitchen"},
        {66237, "Headphones LTPLK", 995.13, "Electronics"},
        {30251, "Pants HCBKI", 450.68, "Clothing"},
        {46944, "Smartwatch QNALX", 647.08, "Electronics"},
        {93533, "Novel WOHSN", 516.39, "Books"},
        {95090, "Cutting Board RBACL", 568.63, "Home& Kitchen"},
        {98827, "Shirt RSQGL", 231.54, "Clothing"},
        {64489, "Novel EFPY", 502.61, "Books"},
        {39148, "Cutting Board OYHCV", 220.15, "Home& Kitchen"},
        {25425, "Mystery MGSPG", 783.17, "Books"},
        {69525, "Camera XROCD", 76.05, "Electronics"},
        {44574, "Knife Set ASRHX", 64.62, "Home & Kitchen"},

    };
    
    //To search for and modify existing product details 
    for (int i = 0; i <= 49; i++)
    {
        if (items[i].Name == "Headphones JFGYQ")
        {
            cout << items[i].Name << " is located at index: " << i << endl;
            items[i].Price = 100;
            cout << "The new price is now $" << items[i].Price << endl;
            break;
        }
    }

    */
    //********************************End of demonstartion for sorting and searching************************



    /*
    //Reading from the file //Could not get file reading to work
    ifstream myFile("product_data.txt");

    int ID;
    string Name;
    double Price;
    string Category;



    while (myFile >> ID >> Name >> Price >> Category)
    {
        cout << ID << ", " << Name << ", " << Price << ", " << Category << endl;
    }

    public void sortingAlgorithm(int items[]) //Attempting to sort the items by price (lowest to highest), was running into some issues. Also not ideal for the size of our array as it is very large. Complexity would have been (O n^2)
    {
        for(int i = 0; i < items.length - 1; i++)
        {
            for(int j = 0; j < items.length - i - 1; j++)
            {
                if(items[j] < items[j+1])
                {
                    int temp price  = items[j];
                    items[j] = items[j+1];
                    items[j+1] = temp price;
                }
            }
        }
    }




    */


}
